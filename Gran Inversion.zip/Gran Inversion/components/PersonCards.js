import Component from 'react';
import './PersonalCards.css';

const PersonalCard = props => {
    render() 
        const lastName = this.props.lastName
        const firstName = this.props.firstName
        const age = this.props.age
        const hairColor = this.props.hairColor
    
    return (
        <div className='PersonalCards'>
            <h1> {props.lastName}, {props.firstName} <h1 />
            <p>Age: {props.age} <p />
            <p>Hair color: {props.hairColor} <p />
        <div />
    );
};

export default PersonalCards;

